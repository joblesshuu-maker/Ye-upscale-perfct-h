import React from 'react';
import { 
  Sparkles, 
  Wand2, 
  RotateCcw, 
  ShieldCheck, 
  Sliders, 
  Check, 
  Info,
  Activity
} from 'lucide-react';
import { EnhancementSliders, VideoAnalysisMetrics } from '../types';

interface EnhancementSlidersCardProps {
  sliders: EnhancementSliders;
  onChange: (sliders: EnhancementSliders) => void;
  onAutoAnalyze: () => void;
  isAnalyzing: boolean;
  analysisMetrics: VideoAnalysisMetrics | null;
}

export const EnhancementSlidersCard: React.FC<EnhancementSlidersCardProps> = ({
  sliders,
  onChange,
  onAutoAnalyze,
  isAnalyzing,
  analysisMetrics,
}) => {
  const updateSlider = (key: keyof EnhancementSliders, value: number | boolean) => {
    onChange({
      ...sliders,
      [key]: value,
    });
  };

  const sliderDefinitions = [
    {
      key: 'neuralSharpness' as const,
      label: '1. Neural Sharpness',
      desc: 'Laplacian high-pass filter with halo-suppression gate.',
      color: 'accent-pink-500',
    },
    {
      key: 'denoise' as const,
      label: '2. Noise Reduction (Denoise)',
      desc: 'Edge-preserving bilateral smoothing for low-light noise.',
      color: 'accent-purple-500',
    },
    {
      key: 'detailRecovery' as const,
      label: '3. Detail & Texture Recovery',
      desc: 'Restores eyelashes, hair strands, and fabric weaves.',
      color: 'accent-rose-500',
    },
    {
      key: 'dynamicContrast' as const,
      label: '4. Dynamic Contrast Lift',
      desc: 'CLAHE tone-curve lifts dark shadows without clipping highlights.',
      color: 'accent-amber-500',
    },
    {
      key: 'vibrance' as const,
      label: '5. Vibrance (Gamut Lift)',
      desc: 'Boosts muted colours without oversaturating skin tones.',
      color: 'accent-teal-500',
    },
    {
      key: 'antiBanding' as const,
      label: '6. Anti-Banding Dither',
      desc: 'Prevents Instagram & TikTok compression algorithms from flattening smooth gradients into ugly banding blocks.',
      color: 'accent-blue-500',
    },
  ];

  return (
    <div className="w-full bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl backdrop-blur-md space-y-4">
      {/* Header with Auto Analyze button */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-pink-400" />
          <h3 className="text-sm font-bold text-white uppercase tracking-wider">
            Enhancement Controls
          </h3>
        </div>

        <button
          type="button"
          onClick={onAutoAnalyze}
          disabled={isAnalyzing}
          className="px-3 py-1.5 rounded-xl bg-pink-500/15 hover:bg-pink-500/25 border border-pink-500/30 text-pink-300 text-xs font-bold flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer disabled:opacity-60"
        >
          <Wand2 className={`w-3.5 h-3.5 ${isAnalyzing ? 'animate-spin' : ''}`} />
          <span>{isAnalyzing ? 'Analyzing...' : 'AUTO Re-Tune'}</span>
        </button>
      </div>

      {/* Honest Analysis Note */}
      {analysisMetrics && (
        <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-start gap-2.5 text-xs">
          <Activity className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <span className="font-semibold text-emerald-300">Live Analysis: </span>
            <span className="text-slate-300">{analysisMetrics.summaryText}</span>
          </div>
        </div>
      )}

      {/* 6 Sliders in Exact Order */}
      <div className="space-y-4 pt-1">
        {sliderDefinitions.map((item) => {
          const val = sliders[item.key] as number;
          return (
            <div key={item.key} className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-200">{item.label}</span>
                <span className="font-mono font-bold text-pink-400 text-[11px] bg-slate-950/80 px-2 py-0.5 rounded-md border border-slate-800">
                  {val}%
                </span>
              </div>
              <p className="text-[11px] text-slate-400 leading-snug">{item.desc}</p>
              <input
                type="range"
                min={0}
                max={100}
                value={val}
                onChange={(e) => updateSlider(item.key, parseInt(e.target.value, 10))}
                className={`w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer ${item.color}`}
              />
            </div>
          );
        })}
      </div>

      {/* Face & Skin Protection Checkbox */}
      <div
        onClick={() => updateSlider('faceProtection', !sliders.faceProtection)}
        className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800/80 hover:border-slate-700/80 transition-all flex items-start gap-3 cursor-pointer select-none pt-2.5"
      >
        <div
          className={`w-5 h-5 rounded-lg border mt-0.5 flex items-center justify-center shrink-0 transition-colors ${
            sliders.faceProtection
              ? 'bg-pink-600 border-pink-500 text-white'
              : 'border-slate-600 bg-slate-900'
          }`}
        >
          {sliders.faceProtection && <Check className="w-3.5 h-3.5 stroke-[2.5]" />}
        </div>
        <div>
          <h4 className="font-bold text-xs text-slate-200">
            Face & Skin Protection
          </h4>
          <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
            Smooths skin while keeping eyes & hair razor sharp.
          </p>
        </div>
      </div>
    </div>
  );
};
