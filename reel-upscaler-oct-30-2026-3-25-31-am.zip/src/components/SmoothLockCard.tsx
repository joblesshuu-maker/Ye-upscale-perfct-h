import React from 'react';
import { ShieldCheck, Check } from 'lucide-react';

interface SmoothLockCardProps {
  isLocked: boolean;
  onToggle: (val: boolean) => void;
}

export const SmoothLockCard: React.FC<SmoothLockCardProps> = ({
  isLocked,
  onToggle,
}) => {
  return (
    <div
      onClick={() => onToggle(!isLocked)}
      className={`w-full p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between select-none ${
        isLocked
          ? 'bg-slate-900/90 border-emerald-500/40 shadow-lg shadow-emerald-500/5'
          : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
      }`}
    >
      <div className="flex items-center gap-3">
        <div
          className={`p-2 rounded-xl border transition-colors ${
            isLocked
              ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400'
              : 'bg-slate-800 border-slate-700 text-slate-400'
          }`}
        >
          <ShieldCheck className="w-5 h-5" />
        </div>
        <div>
          <div className="flex items-center gap-1.5">
            <h4 className="font-bold text-xs text-white">60 FPS Smooth Lock</h4>
            <span
              className={`text-[9px] font-bold px-1.5 py-0.2 rounded-full border ${
                isLocked
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
            >
              {isLocked ? 'LOCKED' : 'OFF'}
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Guaranteed 0 dropped frames • Source FPS strictly preserved
          </p>
        </div>
      </div>

      {/* Switch Toggle */}
      <div
        className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
          isLocked ? 'bg-emerald-600' : 'bg-slate-700'
        }`}
      >
        <div
          className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
            isLocked ? 'translate-x-5' : 'translate-x-0'
          }`}
        />
      </div>
    </div>
  );
};
