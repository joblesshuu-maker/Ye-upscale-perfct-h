import React, { useState, useRef, useEffect } from 'react';
import { Camera, Circle, Square, X, AlertCircle, RefreshCw, Upload } from 'lucide-react';

interface RecordClipModalProps {
  isOpen: boolean;
  onClose: () => void;
  onClipRecorded: (file: File) => void;
  onOpenImport?: () => void;
}

export const RecordClipModal: React.FC<RecordClipModalProps> = ({
  isOpen,
  onClose,
  onClipRecorded,
  onOpenImport,
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordSecondsLeft, setRecordSecondsLeft] = useState(60);
  const [recordError, setRecordError] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const cameraStreamRef = useRef<MediaStream | null>(null);
  const cameraVideoRef = useRef<HTMLVideoElement | null>(null);
  const recordedChunksRef = useRef<BlobPart[]>([]);
  const recordIntervalRef = useRef<any>(null);

  useEffect(() => {
    if (isOpen) {
      startCamera();
    } else {
      stopCameraStream();
    }
    return () => {
      stopCameraStream();
    };
  }, [isOpen]);

  const startCamera = async () => {
    setRecordError(null);
    setRecordSecondsLeft(60);

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Camera API standalone WebView me restricted hai');
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'user',
          width: { ideal: 720 },
          height: { ideal: 1280 },
        },
        audio: true,
      });

      cameraStreamRef.current = stream;
      if (cameraVideoRef.current) {
        cameraVideoRef.current.srcObject = stream;
        cameraVideoRef.current.play().catch(() => {});
      }
    } catch (err: any) {
      console.warn('Camera access notice:', err);
      setRecordError(
        'Camera permission nahi mili — Phone Settings > Apps > Reel Upscaler > Permissions me jaakar Camera allow karein, ya Import se video select karein.'
      );
    }
  };

  const stopCameraStream = () => {
    if (cameraStreamRef.current) {
      cameraStreamRef.current.getTracks().forEach((track) => track.stop());
      cameraStreamRef.current = null;
    }
    if (recordIntervalRef.current) {
      clearInterval(recordIntervalRef.current);
      recordIntervalRef.current = null;
    }
  };

  const startRecordingClip = () => {
    if (!cameraStreamRef.current) return;
    recordedChunksRef.current = [];

    const mimeType = MediaRecorder.isTypeSupported('video/mp4')
      ? 'video/mp4'
      : MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
      ? 'video/webm;codecs=vp9'
      : 'video/webm';

    try {
      const recorder = new MediaRecorder(cameraStreamRef.current, { mimeType });
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) recordedChunksRef.current.push(e.data);
      };

      recorder.onstop = () => {
        const blob = new Blob(recordedChunksRef.current, { type: mimeType });
        const ext = mimeType.includes('mp4') ? 'mp4' : 'webm';
        const recordedFile = new File([blob], `recorded_reel_${Date.now()}.${ext}`, {
          type: mimeType,
        });
        stopCameraStream();
        setIsRecording(false);
        onClipRecorded(recordedFile);
        onClose();
      };

      recorder.start(500);
      mediaRecorderRef.current = recorder;
      setIsRecording(true);
      setRecordSecondsLeft(60);

      recordIntervalRef.current = setInterval(() => {
        setRecordSecondsLeft((prev) => {
          if (prev <= 1) {
            stopRecordingClip();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } catch (e: any) {
      setRecordError('Recording shuru nahi ho saki: ' + e.message);
    }
  };

  const stopRecordingClip = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    if (recordIntervalRef.current) {
      clearInterval(recordIntervalRef.current);
    }
    setIsRecording(false);
  };

  const handleClose = () => {
    stopRecordingClip();
    stopCameraStream();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl flex flex-col items-center gap-3">
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800/60 hover:bg-slate-800 transition-colors cursor-pointer"
          title="Close Camera"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-2 mb-1">
          <Camera className="w-5 h-5 text-pink-400" />
          <h3 className="font-bold text-sm text-white">Record Reel Clip (Max 60s)</h3>
        </div>

        {/* Camera Viewfinder */}
        <div className="relative w-full aspect-[9/16] max-h-[360px] bg-black rounded-2xl overflow-hidden border border-slate-800 flex items-center justify-center">
          <video
            ref={cameraVideoRef}
            playsInline
            muted
            autoPlay
            className="w-full h-full object-cover -scale-x-100"
          />

          {/* Countdown badge when recording */}
          {isRecording && (
            <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-rose-600/90 text-white font-mono font-bold text-xs shadow-lg animate-pulse">
              <span className="w-2 h-2 rounded-full bg-white" />
              <span>0:{recordSecondsLeft < 10 ? '0' : ''}{recordSecondsLeft}</span>
            </div>
          )}
        </div>

        {recordError && (
          <div className="w-full p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-200 text-xs space-y-2">
            <div className="flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span className="leading-tight">{recordError}</span>
            </div>
            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={startCamera}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs flex items-center gap-1 active:scale-95 transition-all cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Retry Camera</span>
              </button>
              {onOpenImport && (
                <button
                  type="button"
                  onClick={() => {
                    handleClose();
                    onOpenImport();
                  }}
                  className="px-3 py-1.5 rounded-xl bg-pink-600 hover:bg-pink-500 text-white font-bold text-xs flex items-center gap-1 active:scale-95 transition-all cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Import Reel Chuno</span>
                </button>
              )}
            </div>
          </div>
        )}

        {/* Record / Stop Button */}
        <div className="w-full pt-1 flex items-center justify-center">
          {!recordError && (
            !isRecording ? (
              <button
                type="button"
                onClick={startRecordingClip}
                className="px-6 py-3 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-rose-600/30 active:scale-95 transition-all cursor-pointer"
              >
                <Circle className="w-4 h-4 fill-white" />
                <span>Recording Shuru Karein</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={stopRecordingClip}
                className="px-6 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center gap-2 border border-slate-700 active:scale-95 transition-all cursor-pointer"
              >
                <Square className="w-4 h-4 fill-white" />
                <span>Clip Save Karein</span>
              </button>
            )
          )}
        </div>
      </div>
    </div>
  );
};
