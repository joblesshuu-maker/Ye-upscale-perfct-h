import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Sliders, Check, Zap, Sparkles } from 'lucide-react';
import { AdvancedSettings, QualityOption, OutputSizeOption } from '../types';

interface AdvancedSettingsCardProps {
  settings: AdvancedSettings;
  onChange: (newSettings: AdvancedSettings) => void;
}

export const AdvancedSettingsCard: React.FC<AdvancedSettingsCardProps> = ({
  settings,
  onChange,
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleQualityChange = (quality: QualityOption) => {
    onChange({ ...settings, quality });
  };

  const handleSizeChange = (outputSize: OutputSizeOption) => {
    onChange({ ...settings, outputSize });
  };

  return (
    <div className="w-full bg-slate-900/60 border border-slate-800/80 rounded-2xl overflow-hidden transition-all">
      {/* Accordion Header (Closed by default) */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full py-3 px-4 flex items-center justify-between text-left hover:bg-slate-800/40 transition-colors"
      >
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-pink-400" />
          <span className="text-xs font-semibold text-slate-200">
            Advanced (optional)
          </span>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700/60">
            {settings.quality === 'best' ? 'Best (crf 14)' : 'Fast (crf 20)'} • {settings.outputSize}
          </span>
        </div>
        {isOpen ? (
          <ChevronUp className="w-4 h-4 text-slate-400" />
        ) : (
          <ChevronDown className="w-4 h-4 text-slate-400" />
        )}
      </button>

      {/* Accordion Content */}
      {isOpen && (
        <div className="p-4 pt-1 border-t border-slate-800/80 space-y-4 text-xs animate-fade-in">
          {/* Choice a: Quality */}
          <div className="space-y-2">
            <label className="font-semibold text-slate-300 block text-[11px] uppercase tracking-wider">
              a. Quality:
            </label>
            <div className="grid grid-cols-1 gap-2">
              {/* Option 1: Best (default) */}
              <button
                type="button"
                onClick={() => handleQualityChange('best')}
                className={`w-full p-3 rounded-xl border text-left flex items-start gap-2.5 transition-all ${
                  settings.quality === 'best'
                    ? 'bg-pink-500/15 border-pink-500/50 text-white'
                    : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full border mt-0.5 flex items-center justify-center shrink-0 ${
                    settings.quality === 'best'
                      ? 'border-pink-400 bg-pink-500'
                      : 'border-slate-600'
                  }`}
                >
                  {settings.quality === 'best' && <Check className="w-2.5 h-2.5 text-white" />}
                </div>
                <div>
                  <div className="font-bold flex items-center gap-1.5 text-xs">
                    <span>Best (crf 14, slow)</span>
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-pink-500/20 text-pink-300 border border-pink-500/30">
                      Default
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Highest crispness and detail retention with Lanczos upscale.
                  </div>
                </div>
              </button>

              {/* Option 2: Fast */}
              <button
                type="button"
                onClick={() => handleQualityChange('fast')}
                className={`w-full p-3 rounded-xl border text-left flex items-start gap-2.5 transition-all ${
                  settings.quality === 'fast'
                    ? 'bg-pink-500/15 border-pink-500/50 text-white'
                    : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full border mt-0.5 flex items-center justify-center shrink-0 ${
                    settings.quality === 'fast'
                      ? 'border-pink-400 bg-pink-500'
                      : 'border-slate-600'
                  }`}
                >
                  {settings.quality === 'fast' && <Check className="w-2.5 h-2.5 text-white" />}
                </div>
                <div>
                  <div className="font-bold flex items-center gap-1.5 text-xs">
                    <span>Fast (crf 20, preset superfast, jaldi hoga, thodi kam quality)</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Phone par jaldi process hoga, reels ke liye kaafi acchi quality.
                  </div>
                </div>
              </button>
            </div>
          </div>

          {/* Choice b: Output Size */}
          <div className="space-y-2">
            <label className="font-semibold text-slate-300 block text-[11px] uppercase tracking-wider">
              b. Output size:
            </label>
            <div className="grid grid-cols-1 gap-2">
              {/* Option 1: 1080p (default) */}
              <button
                type="button"
                onClick={() => handleSizeChange('1080p')}
                className={`w-full p-3 rounded-xl border text-left flex items-start gap-2.5 transition-all ${
                  settings.outputSize === '1080p'
                    ? 'bg-purple-500/15 border-purple-500/50 text-white'
                    : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full border mt-0.5 flex items-center justify-center shrink-0 ${
                    settings.outputSize === '1080p'
                      ? 'border-purple-400 bg-purple-500'
                      : 'border-slate-600'
                  }`}
                >
                  {settings.outputSize === '1080p' && <Check className="w-2.5 h-2.5 text-white" />}
                </div>
                <div>
                  <div className="font-bold flex items-center gap-1.5 text-xs">
                    <span>1080p (Instagram standard)</span>
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                      Default
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Standard 1080x1920 vertical reel format.
                  </div>
                </div>
              </button>

              {/* Option 2: 1440p */}
              <button
                type="button"
                onClick={() => handleSizeChange('1440p')}
                className={`w-full p-3 rounded-xl border text-left flex items-start gap-2.5 transition-all ${
                  settings.outputSize === '1440p'
                    ? 'bg-purple-500/15 border-purple-500/50 text-white'
                    : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full border mt-0.5 flex items-center justify-center shrink-0 ${
                    settings.outputSize === '1440p'
                      ? 'border-purple-400 bg-purple-500'
                      : 'border-slate-600'
                  }`}
                >
                  {settings.outputSize === '1440p' && <Check className="w-2.5 h-2.5 text-white" />}
                </div>
                <div>
                  <div className="font-bold flex items-center gap-1.5 text-xs">
                    <span>1440p (Instagram ko zyada bitrate milta hai, upload ke baad thoda aur crisp)</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Instagram algorithm higher resolution par extra compression bitrate allot karta hai.
                  </div>
                </div>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
