import React, { useState, useEffect } from 'react';
import { 
  FolderOpen, 
  Download, 
  HardDrive, 
  ShieldCheck, 
  AlertCircle, 
  CheckCircle2, 
  XCircle,
  Sparkles,
  RefreshCw,
  Lock,
  X,
  Wifi,
  Cpu,
  MonitorPlay,
  HelpCircle
} from 'lucide-react';
import { PermissionState } from '../types';
import { runHealthCheck } from '../utils/ffmpegManager';

interface PermissionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPermissionsGranted: (file?: File) => void;
  currentPermissions: PermissionState;
}

export const PermissionsModal: React.FC<PermissionsModalProps> = ({
  isOpen,
  onClose,
  onPermissionsGranted,
  currentPermissions,
}) => {
  const [testing, setTesting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // First-Run Self-Test State
  const [isHealthChecking, setIsHealthChecking] = useState(true);
  const [healthStatus, setHealthStatus] = useState<{
    internetOk: boolean;
    engineCoreOk: boolean;
    webglOk: boolean;
    downloadOk: boolean;
    storageOk: boolean;
    fixSuggestions: string[];
  }>({
    internetOk: true,
    engineCoreOk: true,
    webglOk: true,
    downloadOk: true,
    storageOk: true,
    fixSuggestions: [],
  });

  const performHealthCheck = async () => {
    setIsHealthChecking(true);
    try {
      const res = await runHealthCheck();
      setHealthStatus(res);
    } catch (e) {
      console.warn('Health check notice:', e);
    } finally {
      setIsHealthChecking(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      performHealthCheck();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleAllowClick = async () => {
    setTesting(true);
    setErrorMessage(null);

    try {
      // Step 1: Storage Persistence (navigator.storage.persist)
      try {
        if (typeof navigator !== 'undefined' && navigator.storage && navigator.storage.persist) {
          await navigator.storage.persist();
        }
      } catch (err) {
        console.warn('Storage persist notice (non-fatal):', err);
      }

      // Step 2: Download / Save capability test
      let downloadOk = true;
      try {
        const testBlob = new Blob(['reel-upscaler-test'], { type: 'text/plain' });
        const testUrl = URL.createObjectURL(testBlob);
        if (!testUrl || !testUrl.startsWith('blob:')) {
          downloadOk = false;
        }
        URL.revokeObjectURL(testUrl);
      } catch (err) {
        downloadOk = false;
      }

      if (!downloadOk) {
        setErrorMessage('Download test fail ho gaya — phone me storage permission ya Blob URLs check karein.');
        setTesting(false);
        return;
      }

      // Step 3: Trigger file picker once to grant file-read access
      const fileInput = document.createElement('input');
      fileInput.type = 'file';
      fileInput.accept = 'video/mp4,video/quicktime,video/webm,video/x-matroska,.mp4,.mov,.webm,.mkv';
      fileInput.style.display = 'none';
      document.body.appendChild(fileInput);

      let pickedFile: File | undefined = undefined;

      const filePromise = new Promise<boolean>((resolve) => {
        let isResolved = false;

        fileInput.onchange = (e: Event) => {
          if (isResolved) return;
          isResolved = true;
          const target = e.target as HTMLInputElement;
          if (target.files && target.files.length > 0) {
            pickedFile = target.files[0];
          }
          resolve(true);
        };

        const onWindowFocus = () => {
          setTimeout(() => {
            if (!isResolved) {
              isResolved = true;
              window.removeEventListener('focus', onWindowFocus);
              resolve(true);
            }
          }, 600);
        };
        window.addEventListener('focus', onWindowFocus);
      });

      fileInput.click();
      await filePromise;
      if (document.body.contains(fileInput)) {
        document.body.removeChild(fileInput);
      }

      // Save permission state to localStorage
      try {
        localStorage.setItem('reel_upscaler_perms_v1', 'granted');
      } catch {}

      setTesting(false);
      onPermissionsGranted(pickedFile);
    } catch (error: any) {
      console.error('Permission test error:', error);
      setTesting(false);
      setErrorMessage(
        'Permission allow nahi hui. Agar standalone APK me hain, toh Phone Settings > Apps > Reel Upscaler > Permissions me jaakar Files & Media ko Allow karein, phir "Dobara check karo" dabayein.'
      );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl text-slate-100 my-auto">
        {/* Close Button if already permitted once */}
        {currentPermissions.isGranted && (
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800/60 hover:bg-slate-800 transition-colors"
            title="Band karo"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        {/* Header Badge */}
        <div className="flex items-center gap-2 mb-2">
          <div className="p-2 bg-gradient-to-tr from-pink-500/20 to-purple-500/20 border border-pink-500/30 rounded-xl text-pink-400">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              Permissions & Setup
              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-medium">
                100% Free
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Video enhance aur phone me save karne ke liye zaruri access
            </p>
          </div>
        </div>

        {/* FIRST-RUN HEALTH CHECK (Real Pass/Fail Ticks) */}
        <div className="mt-3 p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-pink-400" />
              First-Run Health Check
            </span>
            <button
              type="button"
              onClick={performHealthCheck}
              disabled={isHealthChecking}
              className="text-[10px] text-pink-400 hover:text-pink-300 font-semibold flex items-center gap-1 cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-3 h-3 ${isHealthChecking ? 'animate-spin' : ''}`} />
              <span>{isHealthChecking ? 'Testing...' : 'Re-test'}</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            {/* 1. Internet (reach engine CDN) */}
            <div className={`p-2 rounded-xl border flex items-center justify-between ${
              healthStatus.internetOk 
                ? 'bg-emerald-950/20 border-emerald-800/40 text-emerald-300' 
                : 'bg-rose-950/20 border-rose-800/40 text-rose-300'
            }`}>
              <div className="flex items-center gap-1.5 truncate">
                <Wifi className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">Internet CDN</span>
              </div>
              {healthStatus.internetOk ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              ) : (
                <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
              )}
            </div>

            {/* 2. Engine Core (WebAssembly) */}
            <div className={`p-2 rounded-xl border flex items-center justify-between ${
              healthStatus.engineCoreOk 
                ? 'bg-emerald-950/20 border-emerald-800/40 text-emerald-300' 
                : 'bg-rose-950/20 border-rose-800/40 text-rose-300'
            }`}>
              <div className="flex items-center gap-1.5 truncate">
                <Cpu className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">Engine Core</span>
              </div>
              {healthStatus.engineCoreOk ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              ) : (
                <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
              )}
            </div>

            {/* 3. WebGL Preview */}
            <div className={`p-2 rounded-xl border flex items-center justify-between ${
              healthStatus.webglOk 
                ? 'bg-emerald-950/20 border-emerald-800/40 text-emerald-300' 
                : 'bg-amber-950/20 border-amber-800/40 text-amber-300'
            }`}>
              <div className="flex items-center gap-1.5 truncate">
                <MonitorPlay className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">WebGL GPU</span>
              </div>
              {healthStatus.webglOk ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              ) : (
                <span className="text-[10px] font-bold text-amber-400">2D Mode</span>
              )}
            </div>

            {/* 4. Download & Storage Test */}
            <div className={`p-2 rounded-xl border flex items-center justify-between ${
              healthStatus.downloadOk 
                ? 'bg-emerald-950/20 border-emerald-800/40 text-emerald-300' 
                : 'bg-rose-950/20 border-rose-800/40 text-rose-300'
            }`}>
              <div className="flex items-center gap-1.5 truncate">
                <Download className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">Download / Blob</span>
              </div>
              {healthStatus.downloadOk ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              ) : (
                <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
              )}
            </div>
          </div>

          {/* Health Fix Suggestions if any test failed */}
          {healthStatus.fixSuggestions.length > 0 && (
            <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/25 text-amber-200 text-[11px] space-y-1">
              {healthStatus.fixSuggestions.map((fix, idx) => (
                <div key={idx} className="flex items-start gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                  <span>{fix}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Permissions List in Hinglish */}
        <div className="space-y-2.5 mt-3">
          {/* Permission 1: Video chuno */}
          <div className="p-3 rounded-2xl bg-slate-800/70 border border-slate-700/60 flex items-start gap-3">
            <div className="p-2 rounded-xl bg-pink-500/10 text-pink-400 border border-pink-500/20 shrink-0 mt-0.5">
              <FolderOpen className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold text-xs text-slate-200">
                  1. Video chuno <span className="text-[10px] text-slate-400 font-normal">(File Access)</span>
                </h4>
                {currentPermissions.fileAccess && (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                )}
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5 leading-tight">
                Aapki reel video ko phone se read karke upscale karne ke liye.
              </p>
            </div>
          </div>

          {/* Permission 2: Download / Save */}
          <div className="p-3 rounded-2xl bg-slate-800/70 border border-slate-700/60 flex items-start gap-3">
            <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20 shrink-0 mt-0.5">
              <Download className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold text-xs text-slate-200">
                  2. Download / Save <span className="text-[10px] text-slate-400 font-normal">(Save Access)</span>
                </h4>
                {currentPermissions.downloadCapability && (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                )}
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5 leading-tight">
                Banayi hui enhanced video ko bina kisi watermark ke phone me save karne ke liye.
              </p>
            </div>
          </div>

          {/* Permission 3: Storage */}
          <div className="p-3 rounded-2xl bg-slate-800/70 border border-slate-700/60 flex items-start gap-3">
            <div className="p-2 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20 shrink-0 mt-0.5">
              <HardDrive className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold text-xs text-slate-200">
                  3. Storage <span className="text-[10px] text-slate-400 font-normal">(Files & Media)</span>
                </h4>
                {currentPermissions.persistentStorage && (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                )}
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5 leading-tight">
                Standalone APK me Files & Media access, taaki browser cache memory clear na kare.
              </p>
            </div>
          </div>

          {/* Permission 4: Camera (Optional for Record Clip) */}
          <div className="p-3 rounded-2xl bg-slate-800/70 border border-slate-700/60 flex items-start gap-3">
            <div className="p-2 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/20 shrink-0 mt-0.5">
              <Sparkles className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold text-xs text-slate-200">
                  4. Camera <span className="text-[10px] text-emerald-400 font-normal">(Optional • Record Clip)</span>
                </h4>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5 leading-tight">
                Direct camera se reel record karne ke liye. Agar deny bhi ho, toh bhi Import 100% chalega.
              </p>
            </div>
          </div>
        </div>

        {/* Honest Minimal Permission Notice */}
        <div className="mt-3 flex items-center gap-2 p-2.5 rounded-xl bg-slate-800/40 border border-slate-700/40 text-[11px] text-slate-400">
          <Lock className="w-4 h-4 text-slate-400 shrink-0" />
          <span>
            Mic, contacts ya location access bilkul nahi maangi jaati. Sab kuch 100% private hai.
          </span>
        </div>

        {/* Error / Failure Guidance */}
        {errorMessage && (
          <div className="mt-3 p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-200 text-xs flex items-start gap-2 animate-shake">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div className="flex-1 leading-relaxed">
              <p className="font-semibold mb-0.5 text-rose-300">Zaruri jankari:</p>
              <p>{errorMessage}</p>
            </div>
          </div>
        )}

        {/* Action Button: ALLOW KARO / Dobara try karo */}
        <div className="mt-4 space-y-2">
          <button
            onClick={handleAllowClick}
            disabled={testing}
            className="w-full py-3.5 px-6 rounded-2xl font-bold text-sm bg-gradient-to-r from-pink-600 via-rose-600 to-purple-600 hover:from-pink-500 hover:via-rose-500 hover:to-purple-500 text-white shadow-lg shadow-pink-600/25 active:scale-[0.98] transition-all flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed cursor-pointer"
          >
            {testing ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Checking Permissions...</span>
              </>
            ) : errorMessage ? (
              <>
                <RefreshCw className="w-4 h-4" />
                <span>Dobara try karo (Check again)</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>ALLOW KARO & SHURU KAREIN</span>
              </>
            )}
          </button>

          {errorMessage && (
            <button
              type="button"
              onClick={() => {
                onPermissionsGranted();
                onClose();
              }}
              className="w-full py-2.5 px-4 rounded-xl text-xs text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 transition-colors font-medium text-center cursor-pointer"
            >
              Fir bhi Aage Badhein (Import se shuru karein)
            </button>
          )}

          {currentPermissions.isGranted && !errorMessage && (
            <button
              onClick={onClose}
              className="w-full py-2 text-xs text-slate-400 hover:text-slate-200 text-center font-medium transition-colors cursor-pointer"
            >
              Wapas Main Screen Par Jao
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
