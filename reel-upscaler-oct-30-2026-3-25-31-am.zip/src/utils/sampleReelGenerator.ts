/**
 * Generates a clean 3-second sample 9:16 reel directly in browser
 * for instant one-click testing.
 */
export async function generateSampleReel(): Promise<File> {
  const width = 540;
  const height = 960;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas context not available');

  const stream = canvas.captureStream(30);

  // Try mp4 first, fallback to webm
  const mimeType = MediaRecorder.isTypeSupported('video/mp4')
    ? 'video/mp4'
    : MediaRecorder.isTypeSupported('video/webm;codecs=h264')
    ? 'video/webm;codecs=h264'
    : 'video/webm';

  const recorder = new MediaRecorder(stream, {
    mimeType,
    videoBitsPerSecond: 2500000,
  });

  const chunks: BlobPart[] = [];
  recorder.ondataavailable = (e) => {
    if (e.data.size > 0) chunks.push(e.data);
  };

  const recordingPromise = new Promise<Blob>((resolve) => {
    recorder.onstop = () => {
      resolve(new Blob(chunks, { type: mimeType }));
    };
  });

  recorder.start();

  const totalFrames = 75; // 2.5 seconds at 30fps
  let frame = 0;

  const renderFrame = () => {
    const t = frame / 30;

    // Vibrant Instagram gradient
    const grad = ctx.createLinearGradient(0, 0, width, height);
    grad.addColorStop(0, '#833ab4');
    grad.addColorStop(0.5, '#fd1d1d');
    grad.addColorStop(1, '#fcb045');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);

    // Subtle animated grid / circles
    ctx.fillStyle = 'rgba(255, 255, 255, 0.12)';
    const radius = 100 + Math.sin(t * 3) * 30;
    ctx.beginPath();
    ctx.arc(width / 2, height / 2 - 60, radius, 0, Math.PI * 2);
    ctx.fill();

    // Central card
    ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
    ctx.roundRect?.(40, height / 2 - 140, width - 80, 280, 24);
    ctx.fill();

    // Text labels
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 36px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Reel Upscaler', width / 2, height / 2 - 60);

    ctx.font = '600 20px sans-serif';
    ctx.fillStyle = '#fce7f3';
    ctx.fillText('Test Sample Reel', width / 2, height / 2 - 15);

    ctx.font = '400 16px sans-serif';
    ctx.fillStyle = '#e2e8f0';
    ctx.fillText('540 × 960 (Low Res)', width / 2, height / 2 + 30);
    ctx.fillText('Enhancing to 1080p Lanczos', width / 2, height / 2 + 60);

    // Frame counter
    ctx.font = '14px monospace';
    ctx.fillStyle = '#cbd5e1';
    ctx.fillText(`Frame ${frame + 1} / ${totalFrames}`, width / 2, height - 80);

    frame++;
    if (frame < totalFrames) {
      requestAnimationFrame(renderFrame);
    } else {
      recorder.stop();
    }
  };

  renderFrame();

  const videoBlob = await recordingPromise;
  const fileName = `sample_reel_540x960.${mimeType.includes('mp4') ? 'mp4' : 'webm'}`;
  return new File([videoBlob], fileName, { type: mimeType });
}
