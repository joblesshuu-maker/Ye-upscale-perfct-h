/**
 * WebGL-based High Performance GPU Video Preview Engine
 * True "contain" fit: scale = min(canvasWidth/videoWidth, canvasHeight/videoHeight).
 * Always shows the FULL video frame in its ORIGINAL aspect ratio — never crops or stretches by default.
 */

import { ViewMode, EnhancementSliders } from '../types';

const VERTEX_SHADER_SOURCE = `
attribute vec2 a_position;
attribute vec2 a_texCoord;
varying vec2 v_texCoord;

void main() {
  gl_Position = vec4(a_position, 0.0, 1.0);
  v_texCoord = a_texCoord;
}
`;

const FRAGMENT_SHADER_SOURCE = `
precision mediump float;
varying vec2 v_texCoord;

uniform sampler2D u_image;
uniform vec2 u_canvasResolution;
uniform vec2 u_videoResolution;
uniform float u_zoom;
uniform int u_viewMode; // 0=enhanced, 1=split, 2=side-by-side, 3=original
uniform float u_splitPos;
uniform float u_isHoldingOriginal;
uniform float u_time;

// Slider effect uniforms
uniform float u_sharpness;
uniform float u_denoise;
uniform float u_detail;
uniform float u_contrast;
uniform float u_vibrance;
uniform float u_antiBanding;
uniform float u_faceProtection;

float rgb2luma(vec3 c) {
  return dot(c, vec3(0.299, 0.587, 0.114));
}

float rand(vec2 co) {
  return fract(sin(dot(co.xy, vec2(12.9898, 78.233))) * 43758.5453) - 0.5;
}

bool isSkinTone(vec3 c) {
  float r = c.r * 255.0;
  float g = c.g * 255.0;
  float b = c.b * 255.0;
  float maxVal = max(r, max(g, b));
  float minVal = min(r, min(g, b));
  return (r > 95.0 && g > 40.0 && b > 20.0 && (maxVal - minVal) > 15.0 && abs(r - g) > 15.0 && r > g && r > b);
}

// True "contain" logic: scale = min(boxWidth / videoWidth, boxHeight / videoHeight) * zoom
// Centers the video in the box. Returns false if pixel is in letterbox/pillarbox bars.
bool getContainUV(
  vec2 pixelPos,
  vec2 boxOrigin,
  vec2 boxSize,
  vec2 videoSize,
  float zoom,
  out vec2 outUV
) {
  float scale = min(boxSize.x / videoSize.x, boxSize.y / videoSize.y) * zoom;
  vec2 fittedSize = videoSize * scale;
  vec2 offset = boxOrigin + (boxSize - fittedSize) * 0.5;

  if (pixelPos.x < offset.x || pixelPos.x >= (offset.x + fittedSize.x) ||
      pixelPos.y < offset.y || pixelPos.y >= (offset.y + fittedSize.y)) {
    return false; // In black letterbox/pillarbox bar
  }

  outUV = (pixelPos - offset) / fittedSize;
  return true;
}

void main() {
  // pixelPos: (0,0) at top-left, (canvasWidth, canvasHeight) at bottom-right
  vec2 pixelPos = v_texCoord * u_canvasResolution;

  vec2 videoUV;
  bool isOriginal = (u_isHoldingOriginal > 0.5) || (u_viewMode == 3);
  bool insideVideo = false;

  if (u_viewMode == 2) {
    // ------------------------------------------------------------------
    // Mode 2: Side-by-Side (Left pane Original, Right pane Enhanced)
    // Every pane shows the FULL frame in original ratio with contain fit
    // ------------------------------------------------------------------
    float halfW = u_canvasResolution.x * 0.5;

    // Center divider line
    if (abs(pixelPos.x - halfW) < 1.5) {
      gl_FragColor = vec4(0.35, 0.4, 0.5, 1.0);
      return;
    }

    if (pixelPos.x < halfW) {
      // Left pane: Original
      isOriginal = true;
      insideVideo = getContainUV(pixelPos, vec2(0.0, 0.0), vec2(halfW, u_canvasResolution.y), u_videoResolution, u_zoom, videoUV);
    } else {
      // Right pane: Enhanced
      isOriginal = false;
      insideVideo = getContainUV(pixelPos, vec2(halfW, 0.0), vec2(halfW, u_canvasResolution.y), u_videoResolution, u_zoom, videoUV);
    }
  } else {
    // ------------------------------------------------------------------
    // Mode 0: Enhanced | Mode 1: Split | Mode 3: Original
    // Full preview canvas with contain fit & centered letterbox/pillarbox
    // ------------------------------------------------------------------
    insideVideo = getContainUV(pixelPos, vec2(0.0, 0.0), u_canvasResolution, u_videoResolution, u_zoom, videoUV);

    if (u_viewMode == 1) { // Split
      float splitX = u_canvasResolution.x * u_splitPos;
      if (abs(pixelPos.x - splitX) < 1.5) {
        gl_FragColor = vec4(0.93, 0.28, 0.6, 1.0); // Pink split divider line
        return;
      }
      if (pixelPos.x < splitX) {
        isOriginal = true;
      }
    }
  }

  // Pure black bars for empty contain areas (letterbox / pillarbox)
  if (!insideVideo) {
    gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
    return;
  }

  // Sample original video frame
  vec4 origColor = texture2D(u_image, videoUV);

  if (isOriginal) {
    gl_FragColor = origColor;
    return;
  }

  // ------------------------------------------------------------------
  // Apply GPU Enhancement Pipeline on the fitted video area
  // ------------------------------------------------------------------
  vec2 onePixel = vec2(1.0, 1.0) / u_videoResolution;

  vec3 cCenter = origColor.rgb;
  vec3 cTop    = texture2D(u_image, videoUV + vec2(0.0, -onePixel.y)).rgb;
  vec3 cBottom = texture2D(u_image, videoUV + vec2(0.0,  onePixel.y)).rgb;
  vec3 cLeft   = texture2D(u_image, videoUV + vec2(-onePixel.x, 0.0)).rgb;
  vec3 cRight  = texture2D(u_image, videoUV + vec2( onePixel.x, 0.0)).rgb;

  float lCenter = rgb2luma(cCenter);
  float lTop    = rgb2luma(cTop);
  float lBottom = rgb2luma(cBottom);
  float lLeft   = rgb2luma(cLeft);
  float lRight  = rgb2luma(cRight);
  float lAvg    = (lTop + lBottom + lLeft + lRight) * 0.25;

  bool skin = (u_faceProtection > 0.5) && isSkinTone(cCenter);

  // 1. Neural Sharpness (Laplacian with halo suppression)
  float lap = 4.0 * lCenter - lTop - lBottom - lLeft - lRight;
  float clampedLap = clamp(lap, -0.12, 0.12);
  float sharpAmt = skin ? u_sharpness * 0.25 : u_sharpness;
  float sharpBoost = clampedLap * sharpAmt;

  // 2. Denoise (Edge-preserving bilateral smoothing)
  float edgeDiff = abs(lCenter - lAvg);
  float smoothedLuma = lCenter;
  if (edgeDiff < 0.08 || (skin && edgeDiff < 0.14)) {
    float denoiseBlend = skin ? min(0.65, u_denoise * 0.7) : min(0.5, u_denoise * 0.5);
    smoothedLuma = mix(lCenter, lAvg, denoiseBlend);
  }

  // 3. Detail Recovery
  float detailDelta = (lCenter - lAvg) * (skin ? u_detail * 0.2 : u_detail * 0.6);

  float enhancedLuma = smoothedLuma + sharpBoost + detailDelta;
  float lumaRatio = lCenter > 0.02 ? (enhancedLuma / lCenter) : 1.0;
  vec3 col = cCenter * lumaRatio;

  // 4. Dynamic Contrast Lift (CLAHE shadow-lift S-curve)
  float shadowLift = pow(max(0.0, enhancedLuma), 0.85);
  float contrasted = (shadowLift - 0.5) * u_contrast + 0.5;
  float contrastGain = enhancedLuma > 0.01 ? (contrasted / max(0.01, enhancedLuma)) : 1.0;
  col = mix(col, col * contrastGain, 0.55);

  // 5. Vibrance (Gamut Lift)
  float maxC = max(col.r, max(col.g, col.b));
  float minC = min(col.r, min(col.g, col.b));
  float currentSat = maxC > 0.0 ? (maxC - minC) / maxC : 0.0;
  float satWeight = skin ? u_vibrance * 0.2 : (1.0 - currentSat) * u_vibrance;
  float gray = rgb2luma(col);
  col = mix(col, col + (col - vec3(gray)) * satWeight, 0.8);

  // 6. Anti-Banding Dither
  if (u_antiBanding > 0.0) {
    float n = rand(videoUV + vec2(fract(u_time), 0.0)) * u_antiBanding;
    col += vec3(n);
  }

  gl_FragColor = vec4(clamp(col, 0.0, 1.0), origColor.a);
}
`;

function createShader(gl: WebGLRenderingContext, type: number, source: string): WebGLShader | null {
  const shader = gl.createShader(type);
  if (!shader) return null;
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    console.warn('WebGL shader compile error:', gl.getShaderInfoLog(shader));
    gl.deleteShader(shader);
    return null;
  }
  return shader;
}

export class WebGLPreviewRenderer {
  private gl: WebGLRenderingContext | null = null;
  private program: WebGLProgram | null = null;
  private texture: WebGLTexture | null = null;
  private positionBuffer: WebGLBuffer | null = null;
  private texCoordBuffer: WebGLBuffer | null = null;

  // Uniform locations
  private uCanvasResolutionLoc: WebGLUniformLocation | null = null;
  private uVideoResolutionLoc: WebGLUniformLocation | null = null;
  private uSharpnessLoc: WebGLUniformLocation | null = null;
  private uDenoiseLoc: WebGLUniformLocation | null = null;
  private uDetailLoc: WebGLUniformLocation | null = null;
  private uContrastLoc: WebGLUniformLocation | null = null;
  private uVibranceLoc: WebGLUniformLocation | null = null;
  private uAntiBandingLoc: WebGLUniformLocation | null = null;
  private uFaceProtectionLoc: WebGLUniformLocation | null = null;
  private uViewModeLoc: WebGLUniformLocation | null = null;
  private uSplitPosLoc: WebGLUniformLocation | null = null;
  private uIsHoldingOriginalLoc: WebGLUniformLocation | null = null;
  private uZoomLoc: WebGLUniformLocation | null = null;
  private uTimeLoc: WebGLUniformLocation | null = null;

  public isSupported = false;

  constructor(canvas: HTMLCanvasElement) {
    try {
      const gl = canvas.getContext('webgl', {
        alpha: false,
        depth: false,
        stencil: false,
        antialias: false,
        preserveDrawingBuffer: false,
      });

      if (!gl) {
        this.isSupported = false;
        return;
      }

      this.gl = gl;
      const vertShader = createShader(gl, gl.VERTEX_SHADER, VERTEX_SHADER_SOURCE);
      const fragShader = createShader(gl, gl.FRAGMENT_SHADER, FRAGMENT_SHADER_SOURCE);

      if (!vertShader || !fragShader) {
        this.isSupported = false;
        return;
      }

      const program = gl.createProgram();
      if (!program) {
        this.isSupported = false;
        return;
      }

      gl.attachShader(program, vertShader);
      gl.attachShader(program, fragShader);
      gl.linkProgram(program);

      if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
        console.warn('WebGL program link error:', gl.getProgramInfoLog(program));
        this.isSupported = false;
        return;
      }

      this.program = program;
      gl.useProgram(program);

      // Vertex quad positions (-1 to 1)
      const positions = new Float32Array([
        -1, -1,
         1, -1,
        -1,  1,
        -1,  1,
         1, -1,
         1,  1,
      ]);
      const posBuffer = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, posBuffer);
      gl.bufferData(gl.ARRAY_BUFFER, positions, gl.STATIC_DRAW);
      this.positionBuffer = posBuffer;

      const aPosLoc = gl.getAttribLocation(program, 'a_position');
      gl.enableVertexAttribArray(aPosLoc);
      gl.vertexAttribPointer(aPosLoc, 2, gl.FLOAT, false, 0, 0);

      // Texture UV coordinates (from 0,0 top-left to 1,1 bottom-right)
      const texCoords = new Float32Array([
        0, 1,
        1, 1,
        0, 0,
        0, 0,
        1, 1,
        1, 0,
      ]);
      const texCoordBuf = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, texCoordBuf);
      gl.bufferData(gl.ARRAY_BUFFER, texCoords, gl.STATIC_DRAW);
      this.texCoordBuffer = texCoordBuf;

      const aTexCoordLoc = gl.getAttribLocation(program, 'a_texCoord');
      gl.enableVertexAttribArray(aTexCoordLoc);
      gl.vertexAttribPointer(aTexCoordLoc, 2, gl.FLOAT, false, 0, 0);

      // Setup video texture
      const texture = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, texture);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      this.texture = texture;

      // Uniform Locations
      this.uCanvasResolutionLoc = gl.getUniformLocation(program, 'u_canvasResolution');
      this.uVideoResolutionLoc = gl.getUniformLocation(program, 'u_videoResolution');
      this.uSharpnessLoc = gl.getUniformLocation(program, 'u_sharpness');
      this.uDenoiseLoc = gl.getUniformLocation(program, 'u_denoise');
      this.uDetailLoc = gl.getUniformLocation(program, 'u_detail');
      this.uContrastLoc = gl.getUniformLocation(program, 'u_contrast');
      this.uVibranceLoc = gl.getUniformLocation(program, 'u_vibrance');
      this.uAntiBandingLoc = gl.getUniformLocation(program, 'u_antiBanding');
      this.uFaceProtectionLoc = gl.getUniformLocation(program, 'u_faceProtection');
      this.uViewModeLoc = gl.getUniformLocation(program, 'u_viewMode');
      this.uSplitPosLoc = gl.getUniformLocation(program, 'u_splitPos');
      this.uIsHoldingOriginalLoc = gl.getUniformLocation(program, 'u_isHoldingOriginal');
      this.uZoomLoc = gl.getUniformLocation(program, 'u_zoom');
      this.uTimeLoc = gl.getUniformLocation(program, 'u_time');

      this.isSupported = true;
    } catch (e) {
      console.warn('WebGL initialization failed, falling back to Canvas2D:', e);
      this.isSupported = false;
    }
  }

  public render(
    video: HTMLVideoElement,
    canvasWidth: number,
    canvasHeight: number,
    viewMode: ViewMode,
    splitPos: number,
    isHoldingOriginal: boolean,
    sliders: EnhancementSliders,
    zoom: number
  ) {
    const gl = this.gl;
    if (!gl || !this.program || !this.texture) return;

    if (gl.canvas.width !== canvasWidth || gl.canvas.height !== canvasHeight) {
      gl.canvas.width = canvasWidth;
      gl.canvas.height = canvasHeight;
      gl.viewport(0, 0, canvasWidth, canvasHeight);
    }

    // Upload video frame to GPU texture
    gl.bindTexture(gl.TEXTURE_2D, this.texture);
    try {
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, video);
    } catch {
      return;
    }

    gl.useProgram(this.program);

    const vidW = video.videoWidth || 360;
    const vidH = video.videoHeight || 640;

    // Pass canvas and video dimensions for contain calculations
    gl.uniform2f(this.uCanvasResolutionLoc, canvasWidth, canvasHeight);
    gl.uniform2f(this.uVideoResolutionLoc, vidW, vidH);

    // Pass slider uniforms
    gl.uniform1f(this.uSharpnessLoc, (sliders.neuralSharpness / 100) * 1.5);
    gl.uniform1f(this.uDenoiseLoc, sliders.denoise / 100);
    gl.uniform1f(this.uDetailLoc, (sliders.detailRecovery / 100) * 1.2);
    gl.uniform1f(this.uContrastLoc, 1.0 + (sliders.dynamicContrast / 100) * 0.4);
    gl.uniform1f(this.uVibranceLoc, (sliders.vibrance / 100) * 0.8);
    gl.uniform1f(this.uAntiBandingLoc, (sliders.antiBanding / 100) * 0.08);
    gl.uniform1f(this.uFaceProtectionLoc, sliders.faceProtection ? 1.0 : 0.0);

    const modeMap = {
      fullscreen: 0,
      split: 1,
      'side-by-side': 2,
      original: 3,
    };
    gl.uniform1i(this.uViewModeLoc, modeMap[viewMode] ?? 0);
    gl.uniform1f(this.uSplitPosLoc, splitPos);
    gl.uniform1f(this.uIsHoldingOriginalLoc, isHoldingOriginal ? 1.0 : 0.0);
    gl.uniform1f(this.uZoomLoc, zoom);
    gl.uniform1f(this.uTimeLoc, (Date.now() % 100000) / 1000);

    // Draw full-screen GPU quad
    gl.drawArrays(gl.TRIANGLES, 0, 6);
  }

  public destroy() {
    if (this.gl && this.program) {
      try {
        if (this.texture) this.gl.deleteTexture(this.texture);
        if (this.positionBuffer) this.gl.deleteBuffer(this.positionBuffer);
        if (this.texCoordBuffer) this.gl.deleteBuffer(this.texCoordBuffer);
        this.gl.deleteProgram(this.program);
      } catch {}
    }
    this.gl = null;
    this.program = null;
  }
}
