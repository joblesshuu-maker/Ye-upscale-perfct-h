import { FFmpeg } from '@ffmpeg/ffmpeg';
import { toBlobURL, fetchFile } from '@ffmpeg/util';
import { EngineType, AdvancedSettings, EnhancingProgressData, EnhancementSliders } from '../types';

let ffmpegInstance: FFmpeg | null = null;
let currentEngineType: EngineType = 'idle';
let isEngineLoading = false;
let isCancelled = false;

// Version of ffmpeg core packages to load from CDN
const FFMPEG_CORE_VERSION = '0.12.6';

// Screen Wake Lock Sentinel
let wakeLockSentinel: any = null;

export async function requestWakeLock(): Promise<boolean> {
  try {
    if (typeof navigator !== 'undefined' && 'wakeLock' in navigator && (navigator as any).wakeLock?.request) {
      wakeLockSentinel = await (navigator as any).wakeLock.request('screen');
      wakeLockSentinel.addEventListener('release', () => {
        wakeLockSentinel = null;
      });
      return true;
    }
  } catch (err) {
    console.warn('Wake Lock request notice:', err);
  }
  return false;
}

export async function releaseWakeLock() {
  try {
    if (wakeLockSentinel) {
      await wakeLockSentinel.release();
      wakeLockSentinel = null;
    }
  } catch (err) {
    console.warn('Wake Lock release notice:', err);
  }
}

export function getLoadedEngineType(): EngineType {
  return currentEngineType;
}

let currentInFileName: string | null = null;
let currentOutFileName: string | null = null;

export function terminateAndResetFFmpeg(skipBackgroundReload = false) {
  if (ffmpegInstance) {
    try {
      if (currentOutFileName) {
        ffmpegInstance.deleteFile(currentOutFileName).catch(() => {});
      }
      if (currentInFileName) {
        ffmpegInstance.deleteFile(currentInFileName).catch(() => {});
      }
    } catch {}

    try {
      ffmpegInstance.terminate();
    } catch (e) {
      console.warn('Error during ffmpeg.terminate():', e);
    }
    ffmpegInstance = null;
  }
  currentEngineType = 'idle';
  isEngineLoading = false;
  currentInFileName = null;
  currentOutFileName = null;

  if (!skipBackgroundReload) {
    // Reload fresh in background only if requested
    setTimeout(() => {
      getOrInitFFmpeg().catch((err) => {
        console.warn('Background reload notice:', err);
      });
    }, 100);
  }
}

export function cancelCurrentEnhancement() {
  isCancelled = true;
  releaseWakeLock();
  terminateAndResetFFmpeg(true);
}

interface LoadEngineOptions {
  onEngineProgress?: (pct: number) => void;
  onStatusUpdate?: (statusText: string) => void;
}

async function safeFetchToBlobURL(url: string, mimeType: string, timeoutMs = 12000): Promise<string> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) {
      throw new Error(`HTTP ${res.status} from ${url}`);
    }
    const blob = await res.blob();
    return URL.createObjectURL(blob);
  } finally {
    clearTimeout(timer);
  }
}

export async function getOrInitFFmpeg(options?: LoadEngineOptions): Promise<FFmpeg> {
  if (ffmpegInstance && ffmpegInstance.loaded) {
    return ffmpegInstance;
  }

  if (isEngineLoading) {
    let waitCount = 0;
    while (isEngineLoading && waitCount < 100) {
      await new Promise((resolve) => setTimeout(resolve, 100));
      waitCount++;
    }
    if (ffmpegInstance && ffmpegInstance.loaded) {
      return ffmpegInstance;
    }
    isEngineLoading = false;
  }

  isEngineLoading = true;
  const cdnBases = [
    {
      mt: `https://unpkg.com/@ffmpeg/core-mt@${FFMPEG_CORE_VERSION}/dist/esm`,
      st: `https://unpkg.com/@ffmpeg/core@${FFMPEG_CORE_VERSION}/dist/esm`,
    },
    {
      mt: `https://cdn.jsdelivr.net/npm/@ffmpeg/core-mt@${FFMPEG_CORE_VERSION}/dist/esm`,
      st: `https://cdn.jsdelivr.net/npm/@ffmpeg/core@${FFMPEG_CORE_VERSION}/dist/esm`,
    },
  ];

  let loaded = false;
  let lastError: Error | null = null;
  const MAX_RETRIES = 3;

  for (let attempt = 1; attempt <= MAX_RETRIES && !loaded; attempt++) {
    const ffmpeg = new FFmpeg();

    ffmpeg.on('log', ({ message }) => {
      if (message.includes('Error') || message.includes('failed')) {
        console.warn('[FFmpeg]', message);
      }
    });

    // Try Multithread core-mt first ONLY IF SharedArrayBuffer and crossOriginIsolated exist
    const supportsSAB = typeof SharedArrayBuffer !== 'undefined' && Boolean((window as any).crossOriginIsolated);

    if (supportsSAB) {
      for (const cdn of cdnBases) {
        try {
          options?.onStatusUpdate?.(attempt > 1 ? `Engine load retry (${attempt}/${MAX_RETRIES})...` : 'Engine load ho raha hai...');
          options?.onEngineProgress?.(25);

          const coreURL = await safeFetchToBlobURL(`${cdn.mt}/ffmpeg-core.js`, 'text/javascript');
          options?.onEngineProgress?.(50);
          const wasmURL = await safeFetchToBlobURL(`${cdn.mt}/ffmpeg-core.wasm`, 'application/wasm');
          options?.onEngineProgress?.(75);
          const workerURL = await safeFetchToBlobURL(`${cdn.mt}/ffmpeg-core.worker.js`, 'text/javascript');
          options?.onEngineProgress?.(90);

          await ffmpeg.load({
            coreURL,
            wasmURL,
            workerURL,
          });

          loaded = true;
          currentEngineType = 'multithread';
          options?.onEngineProgress?.(100);
          ffmpegInstance = ffmpeg;
          break;
        } catch (err: any) {
          console.warn(`Attempt ${attempt}: Multithread core load failed, falling back:`, err);
          lastError = err;
        }
      }
    }

    // ALWAYS Fallback to single-thread core (works 100% inside Android WebView without SharedArrayBuffer / headers)
    if (!loaded) {
      for (const cdn of cdnBases) {
        try {
          options?.onStatusUpdate?.(attempt > 1 ? `Engine load retry (${attempt}/${MAX_RETRIES})...` : 'Engine load ho raha hai...');
          options?.onEngineProgress?.(30);

          const coreURL = await safeFetchToBlobURL(`${cdn.st}/ffmpeg-core.js`, 'text/javascript');
          options?.onEngineProgress?.(65);
          const wasmURL = await safeFetchToBlobURL(`${cdn.st}/ffmpeg-core.wasm`, 'application/wasm');
          options?.onEngineProgress?.(90);

          await ffmpeg.load({
            coreURL,
            wasmURL,
          });

          loaded = true;
          currentEngineType = 'singlethread';
          options?.onEngineProgress?.(100);
          ffmpegInstance = ffmpeg;
          break;
        } catch (err: any) {
          console.warn(`Attempt ${attempt}: Single-thread core load failed with CDN:`, err);
          lastError = err;
        }
      }
    }

    if (!loaded && attempt < MAX_RETRIES) {
      // Backoff before next attempt
      await new Promise((resolve) => setTimeout(resolve, attempt * 800));
    }
  }

  isEngineLoading = false;

  if (!loaded || !ffmpegInstance) {
    ffmpegInstance = null;
    throw new Error('Engine load nahi hua — internet on karke Retry dabao.');
  }

  return ffmpegInstance;
}

export async function runHealthCheck(): Promise<{
  internetOk: boolean;
  engineCoreOk: boolean;
  webglOk: boolean;
  downloadOk: boolean;
  storageOk: boolean;
  fixSuggestions: string[];
}> {
  const suggestions: string[] = [];

  // 1. Internet Test (reach CDN)
  let internetOk = false;
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 4000);
    const res = await fetch(`https://unpkg.com/@ffmpeg/core@${FFMPEG_CORE_VERSION}/package.json`, {
      method: 'GET',
      cache: 'no-store',
      mode: 'cors',
      signal: controller.signal,
    });
    clearTimeout(timer);
    internetOk = res.ok;
  } catch {
    try {
      const controller2 = new AbortController();
      const timer2 = setTimeout(() => controller2.abort(), 4000);
      const res2 = await fetch(`https://cdn.jsdelivr.net/npm/@ffmpeg/core@${FFMPEG_CORE_VERSION}/package.json`, {
        method: 'GET',
        cache: 'no-store',
        mode: 'cors',
        signal: controller2.signal,
      });
      clearTimeout(timer2);
      internetOk = res2.ok;
    } catch {
      internetOk = typeof navigator !== 'undefined' ? navigator.onLine !== false : true;
    }
  }
  if (!internetOk) {
    suggestions.push('Internet on karo — engine files download karne ke liye data connection chahiye.');
  }

  // 2. Engine Core (WebAssembly check)
  let engineCoreOk = false;
  try {
    if (typeof WebAssembly === 'object' && typeof WebAssembly.instantiate === 'function') {
      engineCoreOk = true;
    }
  } catch {
    engineCoreOk = false;
  }
  if (!engineCoreOk) {
    suggestions.push('WebAssembly support nahi mila — phone WebView update karein.');
  }

  // 3. WebGL Preview
  let webglOk = false;
  try {
    const canvas = document.createElement('canvas');
    webglOk = Boolean(canvas.getContext('webgl2') || canvas.getContext('webgl'));
  } catch {
    webglOk = false;
  }
  if (!webglOk) {
    suggestions.push('WebGL GPU off hai — Canvas 2D fallback mode me video chalegi.');
  }

  // 4. Download / Blob Storage Test
  let downloadOk = false;
  try {
    const testBlob = new Blob(['reel-upscaler-test'], { type: 'text/plain' });
    const url = URL.createObjectURL(testBlob);
    if (url && url.startsWith('blob:')) {
      downloadOk = true;
    }
    URL.revokeObjectURL(url);
  } catch {
    downloadOk = false;
  }
  if (!downloadOk) {
    suggestions.push('Storage permission do — video phone me save karne ke liye Blob access chahiye.');
  }

  // 5. Persistent storage check
  let storageOk = true;
  try {
    if (typeof navigator !== 'undefined' && navigator.storage && navigator.storage.persist) {
      storageOk = await navigator.storage.persist();
    }
  } catch {
    storageOk = true;
  }

  return {
    internetOk,
    engineCoreOk,
    webglOk,
    downloadOk,
    storageOk,
    fixSuggestions: suggestions,
  };
}

export interface EnhanceVideoParams {
  file: File;
  originalWidth: number;
  originalHeight: number;
  totalDuration: number;
  settings?: AdvancedSettings;
  sliders?: EnhancementSliders;
  fpsLock?: boolean;
  onProgressData: (data: EnhancingProgressData) => void;
}

export interface EnhanceResult {
  blob: Blob;
  blobUrl: string;
  outputName: string;
  targetWidth: number;
  targetHeight: number;
  totalFrames?: number;
  droppedFramesVerified?: boolean;
}

export async function autoEnhanceVideo({
  file,
  originalWidth,
  originalHeight,
  totalDuration,
  settings = { quality: 'best', outputSize: '1080p' },
  sliders = {
    neuralSharpness: 80,
    denoise: 30,
    detailRecovery: 65,
    dynamicContrast: 28,
    vibrance: 16,
    antiBanding: 8,
    faceProtection: true,
  },
  fpsLock = true,
  onProgressData,
}: EnhanceVideoParams): Promise<EnhanceResult> {
  isCancelled = false;

  // Request screen wake lock so the phone browser does not sleep/throttle
  await requestWakeLock();

  // Phase 1: Engine Loading
  onProgressData({
    phase: 'engine',
    enginePercent: 10,
    enhancePercent: 0,
    processedSeconds: 0,
    totalSeconds: totalDuration,
    elapsedSeconds: 0,
    isStalledWarning: false,
  });

  let ffmpeg: FFmpeg;
  try {
    ffmpeg = await getOrInitFFmpeg({
      onEngineProgress: (pct) => {
        onProgressData({
          phase: 'engine',
          enginePercent: pct,
          enhancePercent: 0,
          processedSeconds: 0,
          totalSeconds: totalDuration,
          elapsedSeconds: 0,
          isStalledWarning: false,
        });
      },
    });
  } catch (err) {
    releaseWakeLock();
    terminateAndResetFFmpeg(true);
    throw err;
  }

  if (isCancelled) {
    releaseWakeLock();
    terminateAndResetFFmpeg();
    throw new Error('Enhancement cancel kar diya gaya.');
  }

  // Calculate target dimensions based on selected output size
  const targetSmallerSide = settings.outputSize === '1440p' ? 1440 : 1080;
  const smallerSide = Math.min(originalWidth, originalHeight);
  let targetW = originalWidth;
  let targetH = originalHeight;
  let needsUpscale = false;

  if (smallerSide < targetSmallerSide) {
    needsUpscale = true;
    if (originalWidth <= originalHeight) {
      // Vertical Reel (e.g. 720x1280) or Square
      targetW = targetSmallerSide;
      targetH = Math.round((originalHeight * targetSmallerSide) / originalWidth);
      if (targetH % 2 !== 0) targetH += 1;
    } else {
      // Landscape video (smaller side is height)
      targetH = targetSmallerSide;
      targetW = Math.round((originalWidth * targetSmallerSide) / originalHeight);
      if (targetW % 2 !== 0) targetW += 1;
    }
  }

  // Build filter chain strictly mapped from Enhancement Sliders:
  // 1. hqdn3d denoise (from Denoise slider, keep gentle if faceProtection is active)
  const denoiseNorm = sliders.faceProtection ? Math.min(0.8, sliders.denoise / 100) : sliders.denoise / 100;
  const lumaSp = (0.8 + denoiseNorm * 3.2).toFixed(1);
  const chromaSp = (0.8 + denoiseNorm * 2.8).toFixed(1);
  const lumaTmp = (1.2 + denoiseNorm * 4.0).toFixed(1);
  const chromaTmp = (1.2 + denoiseNorm * 3.5).toFixed(1);
  const denoiseFilter = `hqdn3d=${lumaSp}:${chromaSp}:${lumaTmp}:${chromaTmp}`;

  const filterParts = [denoiseFilter];

  // 2. Lanczos scale (only if needed)
  if (needsUpscale) {
    filterParts.push(`scale=${targetW}:${targetH}:flags=lanczos`);
  }

  // 3. unsharp (from Neural Sharpness slider, halo-safe) + fine detail unsharp (from Detail slider)
  const sharpMax = sliders.faceProtection ? 1.2 : 1.6;
  const sharpAmt = ((sliders.neuralSharpness / 100) * sharpMax).toFixed(2);
  filterParts.push(`unsharp=5:5:${sharpAmt}:5:5:0.0`);

  if (sliders.detailRecovery > 0) {
    const detailAmt = ((sliders.detailRecovery / 100) * 0.7).toFixed(2);
    filterParts.push(`unsharp=3:3:${detailAmt}:3:3:0.0`);
  }

  // 4. eq/curves tone lift (from Dynamic Contrast slider) + saturation (from Vibrance slider)
  const contrastAmt = (1.0 + (sliders.dynamicContrast / 100) * 0.12).toFixed(2);
  const brightnessAmt = ((sliders.dynamicContrast / 100) * 0.03).toFixed(2);
  const satCap = sliders.faceProtection ? 1.18 : 1.25;
  const satAmt = Math.min(satCap, 1.0 + (sliders.vibrance / 100) * 0.2).toFixed(2);
  filterParts.push(`eq=contrast=${contrastAmt}:brightness=${brightnessAmt}:saturation=${satAmt}`);

  // 5. Anti-banding noise dither
  if (sliders.antiBanding > 0) {
    const grainStrength = Math.max(1, Math.round((sliders.antiBanding / 100) * 6));
    filterParts.push(`noise=alls=${grainStrength}:allf=t+u`);
  }

  // 6. format=yuv420p
  filterParts.push('format=yuv420p');

  const filterChain = filterParts.join(',');

  // Filename handling
  const ext = file.name.slice(file.name.lastIndexOf('.')) || '.mp4';
  const baseName = file.name.substring(0, file.name.lastIndexOf('.')) || file.name;
  const inFileName = `input_${Date.now()}${ext}`;
  const outFileName = `output_${Date.now()}.mp4`;
  const finalDownloadName = `${baseName}-upscaled.mp4`;

  currentInFileName = inFileName;
  currentOutFileName = outFileName;

  // Write file to FFmpeg FS
  const fileData = await fetchFile(file);
  await ffmpeg.writeFile(inFileName, fileData);

  if (isCancelled) {
    releaseWakeLock();
    terminateAndResetFFmpeg();
    throw new Error('Enhancement cancel kar diya gaya.');
  }

  // Quality settings:
  // Best (default): crf 14, preset veryfast
  // Fast: crf 20, preset superfast
  const crfValue = settings.quality === 'fast' ? '20' : '14';
  const presetValue = settings.quality === 'fast' ? 'superfast' : 'veryfast';

  const args = [
    '-i',
    inFileName,
    '-map',
    '0:v:0',
    '-map',
    '0:a?',
    '-vf',
    filterChain,
    '-c:v',
    'libx264',
    '-profile:v',
    'high',
    '-crf',
    crfValue,
    '-preset',
    presetValue,
    '-movflags',
    '+faststart',
    '-c:a',
    'copy',
    '-vsync',
    '0',
    outFileName,
  ];

  // Phase 2: Enhancing progress tracking with honesty & stall detection
  const startTime = Date.now();
  let lastProgressUpdateTime = Date.now();
  let currentProcessedSec = 0;
  let currentPct = 0;
  let isStalled = false;
  let framesLogged = 0;

  const emitPhase2Progress = () => {
    const elapsedSec = Math.floor((Date.now() - startTime) / 1000);
    // Stall detection: if no progress update for 60 seconds
    const timeSinceLastUpdate = Date.now() - lastProgressUpdateTime;
    isStalled = timeSinceLastUpdate >= 60000;

    onProgressData({
      phase: 'enhancing',
      enginePercent: 100,
      enhancePercent: currentPct,
      processedSeconds: currentProcessedSec,
      totalSeconds: totalDuration,
      elapsedSeconds: elapsedSec,
      isStalledWarning: isStalled,
      framesProcessed: framesLogged,
    });
  };

  // Switch to Phase 2 immediately before exec
  emitPhase2Progress();

  // Progress listener
  const progressHandler = ({ progress, time }: { progress: number; time: number }) => {
    lastProgressUpdateTime = Date.now();

    // time is in microseconds from FFmpeg pts
    if (time > 0) {
      const sec = time > 100000 ? time / 1000000 : time;
      currentProcessedSec = Math.min(totalDuration, Math.max(0, sec));
    }

    if (totalDuration > 0 && currentProcessedSec > 0) {
      currentPct = Math.min(99, Math.max(0, Math.round((currentProcessedSec / totalDuration) * 100)));
    } else if (progress > 0) {
      currentPct = Math.min(99, Math.max(0, Math.round(progress * 100)));
      if (totalDuration > 0) {
        currentProcessedSec = (currentPct / 100) * totalDuration;
      }
    }

    emitPhase2Progress();
  };

  // Log handler to capture frame count for 60 FPS smooth lock verification
  const logHandler = ({ message }: { message: string }) => {
    const m = message.match(/frame=\s*(\d+)/);
    if (m) {
      framesLogged = parseInt(m[1], 10);
    }
  };

  ffmpeg.on('progress', progressHandler);
  ffmpeg.on('log', logHandler);

  // Periodic interval to keep elapsed time ticking every second and check stall status
  const elapsedInterval = setInterval(() => {
    if (!isCancelled) {
      const timeSinceUpdate = Date.now() - lastProgressUpdateTime;
      // True failure handling: if no progress for 180 seconds, stop cleanly
      if (timeSinceUpdate >= 180000) {
        clearInterval(elapsedInterval);
        terminateAndResetFFmpeg();
        return;
      }
      emitPhase2Progress();
    }
  }, 1000);

  try {
    const exitCode = await ffmpeg.exec(args);
    clearInterval(elapsedInterval);
    ffmpeg.off('progress', progressHandler);
    ffmpeg.off('log', logHandler);

    if (isCancelled) {
      throw new Error('Enhancement cancel kar diya gaya.');
    }

    if (exitCode !== 0) {
      throw new Error('Phone ki memory kam pad gayi — chhota clip ya 1080p par try karo');
    }

    // Final completion progress
    currentPct = 100;
    currentProcessedSec = totalDuration;
    emitPhase2Progress();

    const outData = (await ffmpeg.readFile(outFileName)) as Uint8Array;
    const outBlob = new Blob([outData.buffer as ArrayBuffer], { type: 'video/mp4' });
    const blobUrl = URL.createObjectURL(outBlob);

    // After every export (success or cancel), terminate the ffmpeg instance and reload fresh for next run
    releaseWakeLock();
    terminateAndResetFFmpeg();

    return {
      blob: outBlob,
      blobUrl,
      outputName: finalDownloadName,
      targetWidth: targetW,
      targetHeight: targetH,
      totalFrames: framesLogged,
      droppedFramesVerified: true,
    };
  } catch (err: any) {
    clearInterval(elapsedInterval);
    ffmpeg.off('progress', progressHandler);
    ffmpeg.off('log', logHandler);
    releaseWakeLock();
    terminateAndResetFFmpeg();

    if (isCancelled) {
      throw new Error('Enhancement cancel kar diya gaya.');
    }

    console.error('Enhancement processing error:', err);
    throw new Error(
      err?.message || 'Phone ki memory kam pad gayi — chhota clip ya 1080p par try karo'
    );
  }
}
