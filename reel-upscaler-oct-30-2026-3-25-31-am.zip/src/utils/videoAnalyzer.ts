import { EnhancementSliders, VideoAnalysisMetrics } from '../types';

export const DEFAULT_SLIDERS: EnhancementSliders = {
  neuralSharpness: 80,
  denoise: 30,
  detailRecovery: 65,
  dynamicContrast: 28,
  vibrance: 16,
  antiBanding: 8,
  faceProtection: true,
};

export interface AnalysisResult {
  sliders: EnhancementSliders;
  metrics: VideoAnalysisMetrics;
}

export async function analyzeVideo(
  videoSource: string | File,
  width: number,
  height: number,
  duration: number,
  fileSize: number
): Promise<AnalysisResult> {
  const url = typeof videoSource === 'string' ? videoSource : URL.createObjectURL(videoSource);
  const shouldRevoke = typeof videoSource !== 'string';

  const video = document.createElement('video');
  video.src = url;
  video.muted = true;
  video.playsInline = true;
  video.preload = 'auto';

  try {
    await new Promise<void>((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('Video metadata timeout')), 4000);
      video.onloadedmetadata = () => {
        clearTimeout(timeout);
        resolve();
      };
      video.onerror = () => {
        clearTimeout(timeout);
        reject(new Error('Video failed to load for analysis'));
      };
    });

    const samplePoints = [0.1, 0.3, 0.5, 0.7, 0.9].map((ratio) =>
      Math.max(0.1, Math.min(duration - 0.1, duration * ratio))
    );

    const canvasWidth = 320;
    const canvasHeight = Math.max(180, Math.round((height / width) * canvasWidth));
    const canvas = document.createElement('canvas');
    canvas.width = canvasWidth;
    canvas.height = canvasHeight;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });

    if (!ctx) {
      throw new Error('Canvas 2D context not available');
    }

    let totalLuminance = 0;
    let totalLaplacianVariance = 0;
    let totalNoise = 0;
    let totalSaturation = 0;
    let faceFoundCount = 0;
    let successfulSamples = 0;

    for (const time of samplePoints) {
      try {
        await new Promise<void>((resolve) => {
          let resolved = false;
          const onSeeked = () => {
            if (!resolved) {
              resolved = true;
              video.removeEventListener('seeked', onSeeked);
              resolve();
            }
          };
          video.addEventListener('seeked', onSeeked);
          video.currentTime = time;
          setTimeout(() => {
            if (!resolved) {
              resolved = true;
              video.removeEventListener('seeked', onSeeked);
              resolve();
            }
          }, 600);
        });

        ctx.drawImage(video, 0, 0, canvasWidth, canvasHeight);
        const imgData = ctx.getImageData(0, 0, canvasWidth, canvasHeight);
        const data = imgData.data;
        const totalPixels = canvasWidth * canvasHeight;

        // 1. Luminance & Saturation & Skin pixels
        let frameLum = 0;
        let frameSat = 0;
        let skinPixels = 0;
        const gray = new Float32Array(totalPixels);

        for (let i = 0; i < data.length; i += 4) {
          const r = data[i];
          const g = data[i + 1];
          const b = data[i + 2];

          // Standard ITU-R BT.601 luma
          const lum = 0.299 * r + 0.587 * g + 0.114 * b;
          gray[i / 4] = lum;
          frameLum += lum;

          const max = Math.max(r, g, b);
          const min = Math.min(r, g, b);
          const sat = max === 0 ? 0 : (max - min) / max;
          frameSat += sat;

          // Per-pixel skin color heuristic
          if (r > 95 && g > 40 && b > 20 && max - min > 15 && Math.abs(r - g) > 15 && r > g && r > b) {
            skinPixels++;
          }
        }

        const avgLum = frameLum / totalPixels;
        const avgSat = frameSat / totalPixels;
        totalLuminance += avgLum;
        totalSaturation += avgSat;

        // Face detection check
        let hasFace = false;
        if (typeof (window as any).FaceDetector !== 'undefined') {
          try {
            const detector = new (window as any).FaceDetector({ fastMode: true });
            const faces = await detector.detect(canvas);
            if (faces && faces.length > 0) hasFace = true;
          } catch {}
        }
        if (!hasFace && skinPixels / totalPixels > 0.05) {
          hasFace = true;
        }
        if (hasFace) faceFoundCount++;

        // 2. Laplacian Variance (Sharpness measurement)
        let lapSum = 0;
        let lapSqSum = 0;
        let countedEdges = 0;
        let noiseSum = 0;
        let noiseSamples = 0;

        for (let y = 1; y < canvasHeight - 1; y += 2) {
          for (let x = 1; x < canvasWidth - 1; x += 2) {
            const idx = y * canvasWidth + x;
            const center = gray[idx];
            // 3x3 Laplacian: center * 4 - top - bottom - left - right
            const lap = Math.abs(
              4 * center -
                gray[idx - canvasWidth] -
                gray[idx + canvasWidth] -
                gray[idx - 1] -
                gray[idx + 1]
            );
            lapSum += lap;
            lapSqSum += lap * lap;
            countedEdges++;

            // Measure noise residual in flat areas (where laplacian is small)
            if (lap < 12) {
              const avgNeighbor =
                (gray[idx - canvasWidth] +
                  gray[idx + canvasWidth] +
                  gray[idx - 1] +
                  gray[idx + 1]) /
                4;
              noiseSum += Math.abs(center - avgNeighbor);
              noiseSamples++;
            }
          }
        }

        const meanLap = countedEdges > 0 ? lapSum / countedEdges : 0;
        const varianceLap = countedEdges > 0 ? lapSqSum / countedEdges - meanLap * meanLap : 0;
        const frameNoise = noiseSamples > 0 ? noiseSum / noiseSamples : 0;

        totalLaplacianVariance += varianceLap;
        totalNoise += frameNoise;
        successfulSamples++;
      } catch (sampleErr) {
        console.warn('Frame sample analysis error:', sampleErr);
      }
    }

    if (successfulSamples === 0) {
      throw new Error('Could not analyze sample frames');
    }

    // Averages across sampled frames
    const avgLuminance = totalLuminance / successfulSamples;
    const avgLaplacian = totalLaplacianVariance / successfulSamples;
    const avgNoise = totalNoise / successfulSamples;
    const avgSaturation = totalSaturation / successfulSamples;
    const faceDetected = faceFoundCount >= 1;

    // Compression ratio estimate: bytes per second per pixel
    const compressionEstimate =
      duration > 0 && width > 0 && height > 0
        ? fileSize / (width * height * duration)
        : 0.05;

    // Apply exact Mapping Rules (clamping all sliders 0–100):
    const smallerSide = Math.min(width, height);
    let sharpness = 60;
    let denoise = 30;
    let detail = 50;
    let dynamicContrast = 28;
    let vibrance = 16;
    let antiBanding = 8;
    let faceProtection = true;

    // 1. Base from resolution
    if (smallerSide <= 480) {
      sharpness = 85;
      denoise = 70;
      detail = 70;
    } else if (smallerSide <= 720) {
      sharpness = 80;
      denoise = 50;
      detail = 65;
    } else if (smallerSide <= 1080) {
      sharpness = 60;
      denoise = 30;
      detail = 50;
    } else {
      sharpness = 40;
      denoise = 15;
      detail = 35;
    }

    // 2. Noise adjustment
    const isHighNoise = avgNoise > 3.2;
    if (isHighNoise) {
      denoise = Math.min(90, denoise + 20);
      sharpness = Math.max(10, sharpness - 10);
    }

    // 3. Sharpness adjustment
    const isBlurry = avgLaplacian < 120;
    const isAlreadySharp = avgLaplacian > 600;
    if (isBlurry) {
      sharpness = Math.min(95, sharpness + 20);
      detail = Math.min(100, detail + 15);
    } else if (isAlreadySharp) {
      sharpness = Math.max(15, sharpness - 15);
    }

    // 4. Darkness adjustment (avg luminance below 90)
    const isDark = avgLuminance < 90;
    if (isDark) {
      dynamicContrast = Math.min(80, dynamicContrast + 25);
      denoise = Math.min(95, denoise + 10);
    }

    // 5. Saturation / Color adjustment
    const isWashedOut = avgSaturation < 0.22;
    const isRichColors = avgSaturation > 0.42;
    if (isWashedOut) {
      vibrance = Math.min(100, vibrance + 20);
    } else if (isRichColors) {
      vibrance = 10;
    }

    // 6. Compression estimate (heavily compressed vs clean)
    const isHeavilyCompressed = compressionEstimate < 0.025;
    if (isHeavilyCompressed) {
      antiBanding = Math.min(40, antiBanding + 15);
      denoise = Math.min(95, denoise + 15);
    } else {
      antiBanding = 5;
    }

    // 7. Face protection
    faceProtection = faceDetected;

    // Generate honest summary text reflecting real measurements
    const traits: string[] = [];
    if (smallerSide < 1080) traits.push(`${smallerSide}p`);
    if (isDark) traits.push('dark');
    if (isHighNoise) traits.push('noisy');
    if (isBlurry) traits.push('soft edges');
    if (isAlreadySharp) traits.push('crisp details');
    if (isWashedOut) traits.push('low saturation');
    if (isHeavilyCompressed) traits.push('compression artifacts');
    if (faceDetected) traits.push('face detected');

    let summaryText = '';
    if (isDark && isHighNoise) {
      summaryText = 'Dark + noisy video detect hui — contrast aur denoise boost kiye gaye.';
    } else if (isBlurry && smallerSide <= 720) {
      summaryText = `${smallerSide}p soft video detect hui — neural sharpness aur texture recover set kiye gaye.`;
    } else if (isAlreadySharp && !isHighNoise) {
      summaryText = 'Crisp video detect hui — halo-free natural clarity aur light denoise set hua.';
    } else if (traits.length > 0) {
      summaryText = `${traits.slice(0, 3).join(', ')} detect hui — settings us hisab se auto-tune ki gayi hain.`;
    } else {
      summaryText = 'Balanced video detect hui — 1080p Instagram export ke liye optimal settings set hain.';
    }

    const finalSliders: EnhancementSliders = {
      neuralSharpness: Math.max(0, Math.min(100, Math.round(sharpness))),
      denoise: Math.max(0, Math.min(100, Math.round(denoise))),
      detailRecovery: Math.max(0, Math.min(100, Math.round(detail))),
      dynamicContrast: Math.max(0, Math.min(100, Math.round(dynamicContrast))),
      vibrance: Math.max(0, Math.min(100, Math.round(vibrance))),
      antiBanding: Math.max(0, Math.min(100, Math.round(antiBanding))),
      faceProtection,
    };

    const metrics: VideoAnalysisMetrics = {
      avgLuminance: Math.round(avgLuminance),
      laplacianVariance: Math.round(avgLaplacian),
      noiseEstimate: parseFloat(avgNoise.toFixed(2)),
      avgSaturation: parseFloat(avgSaturation.toFixed(2)),
      compressionEstimate: parseFloat(compressionEstimate.toFixed(4)),
      faceDetected,
      summaryText,
    };

    return {
      sliders: finalSliders,
      metrics,
    };
  } finally {
    if (shouldRevoke) {
      URL.revokeObjectURL(url);
    }
  }
}
